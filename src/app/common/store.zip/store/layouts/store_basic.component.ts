import { Component, Input , Output , EventEmitter } from '@angular/core';

declare var jQuery:any;

@Component({
    selector: 'store_basic',
    templateUrl: 'store_basic.template.html'
})
export class store_basicComponent {

	

}